﻿using LabyrintheLibrary;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.Json;

namespace ConsoleLabyrinthe
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Labyrinthe lb = (File.Exists("obj.bin") ? Labyrinthe.Deserialize("obj.bin") : new Labyrinthe(21,21));
            lb.Generer();
            lb.Serialize("obj.bin");
            Console.WriteLine("Termine");
           
        }
    }
}